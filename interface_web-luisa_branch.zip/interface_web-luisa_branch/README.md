# interface_web

### To launch: 

1) Make sure you have FastAPI installed. Otherwise do:
```pip install fastapi uvicorn```

2) Launch
```uvicorn main:app --reload```.  
Hopefully it works.

3) Next go to
```http://localhost:8000```.  
Ta-dam! Enjoy.
